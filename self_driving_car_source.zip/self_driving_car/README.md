# Autonomy in Motion

30-second educational animation, 720 × 1280, 9:16 portrait, 30 fps. Silent MP4 suitable for adding narration/music in a video editor.

Open index.html in a desktop browser to play the animation. All assets are local; no packages are needed for playback. Click Play / Pause to pause.

## Roles
- planner.cpp: C++17 executable generates position, speed and steering telemetry.
- telemetry.js: generated data used by the browser, bundled for immediate playback.
- animation.js: draws road geometry, illustrative sensor returns, object tracks, candidate paths, selected path and controls.
- index.html / style.css: browser player and responsive presentation.

## Regenerate telemetry
```
g++ -std=c++17 -O2 planner.cpp -o planner
./planner > telemetry.json
python3 -c "from pathlib import Path; Path('telemetry.js').write_text('const telemetry='+Path('telemetry.json').read_text()+';')"
```

## Render MP4
The included render.cjs requires Node.js, Playwright, Chromium and FFmpeg. Adjust its Chromium executable path for your machine. Create a sibling deliverables directory, then run `node render.cjs`. Rendered output is written to ../deliverables/self_driving_car.mp4.

## Educational scope
This is a scripted visualization, not autonomous-driving software or a physical vehicle model. C++ generates smooth passing and speed profiles; steering is an illustrative angle derived from lateral motion. Object detection and sensor dots are scripted. The route is assumed clear and legally passable; real systems must check road rules, uncertainty, visibility and collision risk. A general autonomy pipeline includes perception, localization, prediction, planning, and feedback control. Sensor configurations differ between vehicles. The road view is a schematic, not a calibrated sensor display.

Alternatively, render_canvas.cjs uses @napi-rs/canvas and FFmpeg to export the same JavaScript drawing without Chromium. Adjust the font path if needed.
