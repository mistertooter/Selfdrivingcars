#include <iostream>
#include <cmath>
#include <algorithm>
// Educational trajectory generator: perception is scripted, not real sensor AI.
double smooth(double a,double b,double t){double u=std::clamp((t-a)/(b-a),0.0,1.0);return u*u*(3-2*u);}
int main(){std::cout<<"[";for(int i=0;i<=900;i++){double t=i/30.0;double x=-110*smooth(10,14,t)+110*smooth(18,22,t);double v=48-30*smooth(23,26,t)+30*smooth(28,30,t);double dx=(-110*(smooth(10,14,t+.02)-smooth(10,14,t))+110*(smooth(18,22,t+.02)-smooth(18,22,t)))/.02;double steer=atan2(dx,v*8)*180/3.14159265;if(i)std::cout<<",";std::cout<<"{\"t\":"<<t<<",\"x\":"<<x<<",\"speed\":"<<v<<",\"steer\":"<<steer<<"}";}std::cout<<"]";}
