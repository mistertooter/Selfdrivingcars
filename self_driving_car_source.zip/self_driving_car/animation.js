const canvas=document.getElementById('film'),c=canvas.getContext('2d');let paused=false;
const chapters=[['01 / SENSE','Build a picture of the road','Cameras see lanes and signals.','Radar measures range and relative speed.'],['02 / UNDERSTAND','Fuse observations into tracks','Estimate where objects are moving.','Combine lane geometry with localization.'],['03 / PLAN','Choose a clear, legal path','A stopped vehicle blocks our lane.','Check the adjacent lane before passing.'],['04 / CONTROL','Turn the plan into movement','Steering follows the selected trajectory.','Feedback corrects position continuously.'],['05 / YIELD','Slow down for a crossing','Predict the pedestrian’s possible motion.','Brake early and preserve a safety margin.']];
function text(s,x,y,size=24,color='#e5f2ff',weight=400){c.fillStyle=color;size*=1.14;c.font=`${weight} ${size}px Arial`;const available=674-x;if(c.measureText(s).width>available){size*=available/c.measureText(s).width;c.font=`${weight} ${size}px Arial`;}c.fillText(s,x,y)}
function line(x,y,X,Y,col,w=2,dash=[]){c.beginPath();c.setLineDash(dash);c.strokeStyle=col;c.lineWidth=w;c.moveTo(x,y);c.lineTo(X,Y);c.stroke();c.setLineDash([])}
function box(x,y,w,h,col,r=14){c.fillStyle=col;c.beginPath();c.roundRect(x,y,w,h,r);c.fill()}
function car(x,y,color,angle=0,ego=false){c.save();c.translate(x,y);c.rotate(angle);c.shadowColor=color;c.shadowBlur=ego?24:10;box(-29,-53,58,106,color,15);c.shadowBlur=0;box(-23,-29,46,24,'#09243b',7);box(-23,20,46,20,'#09243b',7);box(-34,-33,5,22,'#010713',2);box(29,-33,5,22,'#010713',2);box(-34,23,5,22,'#010713',2);box(29,23,5,22,'#010713',2);box(-24,-51,12,5,'#e9ffff',2);box(12,-51,12,5,'#e9ffff',2);if(ego){c.fillStyle='#fff';c.beginPath();c.arc(0,0,7,0,7);c.fill()}c.restore()}
function render(t){t=Math.max(0,Math.min(29.999,t));const k=Math.min(4,Math.floor(t/6)),ch=chapters[k],a=telemetry[Math.min(900,Math.round(t*30))];
c.fillStyle='#050c1c';c.fillRect(0,0,720,1280);let g=c.createRadialGradient(360,500,10,360,600,700);g.addColorStop(0,'#12324b');g.addColorStop(1,'#050c1c');c.fillStyle=g;c.fillRect(0,0,720,1280);
text('AUTONOMY / IN MOTION',46,66,20,'#5ee9f3',700);text('How a car',46,119,47,'#fff',700);text('knows where to go.',46,171,47,'#fff',700);text(ch[0],46,220,20,'#f9ca64',700);
// Road bends, with the same geometry used by lane markings and vehicles.
const bend=y=>26*Math.sin((y/700)+t*.12);const center=y=>360+bend(y);const cy=800,cx=center(cy)+55+a.x;
c.save();c.beginPath();for(let y=270;y<=960;y+=5){let x=center(y)-182;y===270?c.moveTo(x,y):c.lineTo(x,y)}for(let y=960;y>=270;y-=5)c.lineTo(center(y)+182,y);c.closePath();c.fillStyle='#263347';c.fill();
for(let side of [-1,1]){c.beginPath();for(let y=270;y<=960;y+=5){let x=center(y)+side*171;y===270?c.moveTo(x,y):c.lineTo(x,y)}c.strokeStyle='#65e5d1';c.lineWidth=4;c.stroke()}
for(let y=270-((t*110)%80);y<960;y+=80)line(center(y),y,center(y+36),y+36,'#e7eaf1',4);
// Roadside city blocks and trees.
for(let i=0;i<7;i++){let y=290+((i*115+t*55)%650);box(47,y,60,64,'#122941',9);box(600,y+30,66,55,'#16374b',9);c.fillStyle='#52d7a5';c.beginPath();c.arc(133,y+20,13,0,7);c.fill()}
let oy=t<20?cy-(12-t)*35:1100;let ox=center(oy)+55;if(oy>300&&oy<1000){car(ox,oy,'#ffad48');c.strokeStyle='#ffba60';c.lineWidth=2;c.strokeRect(ox-42,oy-65,84,130);text('STOPPED',ox-47,oy-78,16,'#ffd391',700)}
// Adjacent lane is clear in this scripted passing scenario.
// Sensor fans and returns.
for(let j=0;j<3;j++){let r=80+((t*70+j*65)%220);c.beginPath();c.ellipse(cx,cy,r*.68,r,0,Math.PI*1.1,Math.PI*1.9);c.strokeStyle=`rgba(55,225,249,${.42*(1-r/350)})`;c.lineWidth=2;c.stroke()}
for(let i=0;i<55;i++){let q=i*2.399;let r=70+(i*29%240);let x=cx+Math.cos(q)*r*.64,y=cy-60-Math.abs(Math.sin(q))*r;if(y>280){c.fillStyle=i%3?'#55d9f4':'#e1a8ff';c.fillRect(x,y,3,3)}}
// Candidate paths, selected trajectory.
for(let j of [-1,1]){c.beginPath();c.moveTo(cx,cy);c.bezierCurveTo(cx,650,cx+j*100,520,cx+j*100,380);c.strokeStyle='#a6bdd52b';c.lineWidth=3;c.stroke()}
let target=t>=10&&t<18?-55:55;c.beginPath();c.moveTo(cx,cy);c.bezierCurveTo(cx,660,center(530)+target,560,center(340)+target,340);c.strokeStyle='#6df0ac';c.lineWidth=7;c.shadowColor='#5cffba';c.shadowBlur=15;c.stroke();c.shadowBlur=0;
if(t>23){let py=493;for(let i=0;i<7;i++)box(204+i*46,py,25,64,'#e3eced',2);let px=210+Math.min(1,(t-23)/6)*300;c.fillStyle='#ff6d9d';c.beginPath();c.arc(px,py+20,15,0,7);c.fill();line(px,py+30,px,py+55,'#ff6d9d',8);c.strokeStyle='#ff6d9d';c.strokeRect(px-25,py-5,50,75);text('PEDESTRIAN',222,py-20,18,'#ff92b5',700)}
car(cx,cy,'#49ddfa',a.steer*Math.PI/180,true);text('EGO',cx-18,cy+82,16,'#9ff6ff',700);c.restore();
box(38,278,300,38,'#071628dc',10);text('SENSOR + PLANNING VIEW',51,304,16,'#91edff',700);
box(38,907,644,66,'#071628ee',15);text(Math.round(a.speed)+' km/h',58,948,27,'#fff',700);text('STEER '+a.steer.toFixed(1)+'°',254,948,22,'#60e3ff',700);text(t>23?'YIELD':t>10&&t<19?'PASS':'FOLLOW',522,948,22,'#7bf3b6',700);
text(ch[1],46,1029,31,'#fff',700);text(ch[2],46,1070,23);text(ch[3],46,1105,23);
const labels=['SENSE','FUSE','PLAN','ACT','YIELD'];for(let i=0;i<5;i++){box(46+i*127,1140,117,40,i===k?'#43d5ed':'#193047',9);text(labels[i],58+i*127,1166,17,i===k?'#042238':'#8aa8c5',700)}
text('Conceptual simulation • sensors vary by vehicle',46,1216,17,'#91a5bc');text('C++ trajectory engine  /  JavaScript + HTML + CSS',46,1246,16,'#70899f');box(46,1264,628*(t/30),3,'#55e4f2',1);
}
window.render=render;let start=null,elapsed=0;function loop(now){if(start===null)start=now;if(!paused)elapsed+=(now-start)/1000;start=now;render(elapsed%30);requestAnimationFrame(loop)}if(!location.search.includes('capture'))requestAnimationFrame(loop);else render(0);
